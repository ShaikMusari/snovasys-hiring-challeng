# TrustVault — Secure Document Sharing

A Flask + SQLite starter application demonstrating secure document uploads, user accounts, role-based access, explicit sharing, audit logs and SHA-256 integrity checks.

## Features
- User registration and password hashing
- Admin and regular-user roles
- Secure filename handling and allowed file extensions
- 10 MB upload limit
- Document ownership and explicit sharing permissions
- Download authorization checks
- SHA-256 hash recorded at upload and verified at download
- Audit events for login, upload, sharing, downloads, denied access and integrity failures
- Responsive dashboard

## Run locally
1. Install Python 3.11 or newer.
2. Open a terminal in this folder.
3. Run `python -m venv .venv`
4. Activate it:
   - Windows PowerShell: `.venv\Scripts\Activate.ps1`
   - macOS/Linux: `source .venv/bin/activate`
5. Run `pip install -r requirements.txt`
6. Set a strong secret key and admin password before public use:
   - Windows PowerShell: `$env:SECRET_KEY="replace-with-a-long-random-secret"; $env:ADMIN_PASSWORD="your-strong-admin-password"`
   - macOS/Linux: `export SECRET_KEY="replace-with-a-long-random-secret"; export ADMIN_PASSWORD="your-strong-admin-password"`
7. Run `python app.py`
8. Visit `http://127.0.0.1:5000`

## Initial admin
The app creates an `admin` account on first startup. For local testing, the fallback password is `ChangeMe123!`. Set `ADMIN_PASSWORD` before the first run and change it for any public deployment. Do not use the fallback password on a public service.

## Deploy on Render
1. Push the project files to a GitHub repository.
2. On Render, create a new **Web Service** and connect that repository.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app`
5. Add environment variables `SECRET_KEY` and `ADMIN_PASSWORD`.
6. Note: a free instance's local disk may be ephemeral. For a production deployment, configure persistent storage and a managed database; this demo's SQLite database and uploaded files may not survive instance replacement/redeploy.

## Important limitations
This is an educational starter, not a production-certified document vault. Before real sensitive data is used, add CSRF protection, rate limiting, secure cookie configuration, password reset, persistent storage, backups, malware scanning, and stronger audit-log protection. Never upload real confidential documents to a demo deployment.
