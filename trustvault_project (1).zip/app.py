import os, sqlite3, hashlib, secrets
from datetime import datetime
from functools import wraps
from flask import Flask, request, redirect, url_for, session, flash, render_template_string, send_from_directory, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

APP_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_DIR = os.path.join(APP_DIR, "uploads")
DB_PATH = os.path.join(APP_DIR, "trustvault.db")
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", secrets.token_hex(32))
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024
ALLOWED_EXTENSIONS = {"pdf", "png", "jpg", "jpeg", "txt", "docx", "xlsx"}

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user')""")
        con.execute("""CREATE TABLE IF NOT EXISTS documents(
            id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT NOT NULL,
            stored_name TEXT NOT NULL, owner_id INTEGER NOT NULL,
            sha256 TEXT NOT NULL, uploaded_at TEXT NOT NULL,
            shared_with TEXT DEFAULT '')""")
        con.execute("""CREATE TABLE IF NOT EXISTS audit_logs(
            id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL,
            action TEXT NOT NULL, details TEXT NOT NULL, created_at TEXT NOT NULL)""")
        count = con.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
        if count == 0:
            con.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",
                        ("admin", generate_password_hash(os.environ.get("ADMIN_PASSWORD", "ChangeMe123!")), "admin"))

def audit(action, details):
    username = session.get("username", "anonymous")
    with db() as con:
        con.execute("INSERT INTO audit_logs(username,action,details,created_at) VALUES(?,?,?,?)",
                    (username, action, details[:500], datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")))

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def page(body, **kwargs):
    common = dict(title="TrustVault", user=session.get("username"), role=session.get("role"))
    common.update(kwargs)
    return render_template_string(BASE + body, **common)

BASE = """
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{{ title }}</title><style>
*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;background:#f3f6fb;color:#172033}
nav{background:#101b35;color:white;padding:17px 5%;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
nav a{color:white;text-decoration:none;margin-left:14px}.brand{font-weight:700;font-size:21px}
main{max-width:1000px;margin:30px auto;padding:0 16px}.card{background:white;border:1px solid #e1e7f0;border-radius:12px;padding:22px;margin:16px 0;box-shadow:0 3px 14px #14264a0a}
h1{margin-top:0}input,select,button{padding:11px;border:1px solid #cbd5e1;border-radius:7px;font-size:14px;max-width:100%}
input[type=text],input[type=password],input[type=file]{width:100%;margin:6px 0 12px}button,.btn{background:#2563eb;color:white;border:0;cursor:pointer;text-decoration:none;display:inline-block;padding:10px 14px;border-radius:7px}
table{width:100%;border-collapse:collapse;background:white}th,td{text-align:left;padding:11px;border-bottom:1px solid #e5eaf2;overflow-wrap:anywhere}th{background:#f8fafc}
.flash{padding:10px;border-radius:7px;background:#fff3cd;margin:10px 0}.muted{color:#64748b;font-size:13px}.pill{background:#e0ecff;color:#1746a2;padding:4px 8px;border-radius:20px;font-size:12px}
@media(max-width:650px){table{font-size:12px}th,td{padding:7px}.card{padding:15px}}
</style></head><body><nav><div class="brand">🔐 TrustVault</div><div>{% if user %}Signed in as {{ user }} · {{ role }} <a href="{{ url_for('dashboard') }}">Dashboard</a><a href="{{ url_for('logout') }}">Logout</a>{% endif %}</div></nav><main>
{% with messages=get_flashed_messages() %}{% for m in messages %}<div class="flash">{{ m }}</div>{% endfor %}{% endwith %}
""" + "{{ body|safe }}" + """</main></body></html>"""

@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        if len(username) < 3 or len(password) < 8:
            flash("Username must be at least 3 characters and password at least 8 characters.")
        else:
            try:
                with db() as con:
                    con.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",
                                (username, generate_password_hash(password), "user"))
                audit("REGISTER", f"New account: {username}")
                flash("Account created. Please sign in.")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("That username already exists.")
    return page("""<div class="card" style="max-width:460px;margin:30px auto"><h1>Create account</h1><form method="post">
    <label>Username</label><input name="username" required minlength="3">
    <label>Password (minimum 8 characters)</label><input name="password" type="password" required minlength="8">
    <button>Create account</button></form><p>Already registered? <a href="{{ url_for('login') }}">Sign in</a></p></div>""")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        with db() as con:
            user = con.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session.update(user_id=user["id"], username=user["username"], role=user["role"])
            audit("LOGIN", "Successful sign in")
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.")
    return page("""<div class="card" style="max-width:460px;margin:30px auto"><h1>Welcome to TrustVault</h1>
    <p class="muted">Secure document sharing with access control and audit history.</p><form method="post">
    <label>Username</label><input name="username" required>
    <label>Password</label><input name="password" type="password" required>
    <button>Sign in</button></form><p>New here? <a href="{{ url_for('register') }}">Create an account</a></p>
    <p class="muted">First admin account: admin · ChangeMe123! (change this before public deployment)</p></div>""")

@app.route("/logout")
@login_required
def logout():
    audit("LOGOUT", "Signed out")
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    with db() as con:
        if session.get("role") == "admin":
            docs = con.execute("SELECT d.*,u.username owner FROM documents d JOIN users u ON u.id=d.owner_id ORDER BY d.id DESC").fetchall()
        else:
            docs = con.execute("""SELECT d.*,u.username owner FROM documents d JOIN users u ON u.id=d.owner_id
                WHERE d.owner_id=? OR ',' || d.shared_with || ',' LIKE ? ORDER BY d.id DESC""",
                (session["user_id"], "%,"+session["username"]+",%")).fetchall()
        users = con.execute("SELECT username FROM users ORDER BY username").fetchall()
    rows = "".join(f"<tr><td>{d['filename']}</td><td>{d['owner']}</td><td><span class='pill'>{d['sha256'][:12]}…</span></td><td>{d['uploaded_at']}</td><td><a class='btn' href='/download/{d['id']}'>Download</a></td></tr>" for d in docs)
    user_options = "".join(f"<option>{u['username']}</option>" for u in users if u["username"] != session["username"])
    admin_link = '<a class="btn" href="/audit">View audit log</a>' if session.get("role") == "admin" else '<a class="btn" href="/audit">My audit history</a>'
    body = f"""<h1>Dashboard</h1><p class="muted">Upload, share and verify your documents.</p>
    <div class="card"><h2>Upload document</h2><form method="post" action="/upload" enctype="multipart/form-data">
    <input type="file" name="file" required><button>Upload securely</button></form><p class="muted">Allowed: PDF, PNG, JPG, TXT, DOCX, XLSX · Maximum 10 MB</p></div>
    <div class="card"><h2>Share a document</h2><form method="post" action="/share"><label>Document</label><select name="doc_id" required>"""
    body += "".join(f"<option value='{d['id']}'>{d['filename']} (ID {d['id']})</option>" for d in docs if d["owner_id"] == session["user_id"] or session.get("role") == "admin")
    body += f"""</select><label>Share with user</label><select name="target" required>{user_options}</select><button>Grant access</button></form><p class="muted">Only the owner or admin can share a document.</p></div>
    <div class="card"><h2>Available documents</h2><div style="overflow-x:auto"><table><tr><th>File</th><th>Owner</th><th>SHA-256</th><th>Uploaded</th><th>Action</th></tr>{rows or '<tr><td colspan="5">No documents available yet.</td></tr>'}</table></div></div>
    <p>{admin_link}</p>"""
    return page(body)

@app.route("/upload", methods=["POST"])
@login_required
def upload():
    f = request.files.get("file")
    if not f or not f.filename:
        flash("Choose a file first.")
        return redirect(url_for("dashboard"))
    original = secure_filename(f.filename)
    ext = original.rsplit(".",1)[-1].lower() if "." in original else ""
    if ext not in ALLOWED_EXTENSIONS:
        flash("File type not allowed.")
        audit("UPLOAD_REJECTED", f"Blocked file type: {original}")
        return redirect(url_for("dashboard"))
    stored = secrets.token_hex(16) + "_" + original
    path = os.path.join(UPLOAD_DIR, stored)
    f.save(path)
    h = hashlib.sha256()
    with open(path,"rb") as stream:
        for chunk in iter(lambda: stream.read(8192), b""):
            h.update(chunk)
    with db() as con:
        con.execute("INSERT INTO documents(filename,stored_name,owner_id,sha256,uploaded_at,shared_with) VALUES(?,?,?,?,?,?)",
                    (original,stored,session["user_id"],h.hexdigest(),datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),""))
    audit("UPLOAD", f"Uploaded {original}; SHA-256 {h.hexdigest()}")
    flash("Document uploaded and SHA-256 integrity hash recorded.")
    return redirect(url_for("dashboard"))

@app.route("/share", methods=["POST"])
@login_required
def share():
    try: doc_id = int(request.form.get("doc_id","0"))
    except ValueError: doc_id = 0
    target = request.form.get("target","")
    with db() as con:
        doc = con.execute("SELECT * FROM documents WHERE id=?", (doc_id,)).fetchone()
        target_user = con.execute("SELECT id FROM users WHERE username=?", (target,)).fetchone()
        if not doc or not target_user or (doc["owner_id"] != session["user_id"] and session.get("role") != "admin"):
            abort(403)
        names = [x for x in (doc["shared_with"] or "").split(",") if x]
        if target not in names: names.append(target)
        con.execute("UPDATE documents SET shared_with=? WHERE id=?", (",".join(names),doc_id))
    audit("SHARE", f"Document {doc_id} shared with {target}")
    flash(f"Access granted to {target}.")
    return redirect(url_for("dashboard"))

@app.route("/download/<int:doc_id>")
@login_required
def download(doc_id):
    with db() as con:
        doc = con.execute("SELECT * FROM documents WHERE id=?", (doc_id,)).fetchone()
    if not doc: abort(404)
    allowed = (doc["owner_id"] == session["user_id"] or session.get("role") == "admin" or
               session.get("username") in (doc["shared_with"] or "").split(","))
    if not allowed:
        audit("ACCESS_DENIED", f"Blocked download of document {doc_id}")
        abort(403)
    path = os.path.join(UPLOAD_DIR, doc["stored_name"])
    if not os.path.isfile(path): abort(404)
    h = hashlib.sha256()
    with open(path,"rb") as stream:
        for chunk in iter(lambda: stream.read(8192), b""): h.update(chunk)
    if h.hexdigest() != doc["sha256"]:
        audit("INTEGRITY_FAILURE", f"Hash mismatch for document {doc_id}")
        abort(409, "Integrity check failed")
    audit("DOWNLOAD", f"Downloaded {doc['filename']}; integrity verified")
    return send_from_directory(UPLOAD_DIR, doc["stored_name"], as_attachment=True, download_name=doc["filename"])

@app.route("/audit")
@login_required
def audit_page():
    with db() as con:
        if session.get("role") == "admin":
            logs = con.execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 200").fetchall()
        else:
            logs = con.execute("SELECT * FROM audit_logs WHERE username=? ORDER BY id DESC LIMIT 100", (session["username"],)).fetchall()
    rows = "".join(f"<tr><td>{x['created_at']}</td><td>{x['username']}</td><td>{x['action']}</td><td>{x['details']}</td></tr>" for x in logs)
    return page(f"""<h1>Audit history</h1><div class="card"><p class="muted">Records account activity, uploads, sharing, downloads, denied access and integrity checks.</p>
    <div style="overflow-x:auto"><table><tr><th>Time (UTC)</th><th>User</th><th>Action</th><th>Details</th></tr>{rows or '<tr><td colspan="4">No log records yet.</td></tr>'}</table></div><p><a class="btn" href="/dashboard">Back to dashboard</a></p></div>""")

@app.errorhandler(403)
def forbidden(e):
    return page("<div class='card'><h1>403 · Access denied</h1><p>You do not have permission to access this resource.</p><a class='btn' href='/dashboard'>Back to dashboard</a></div>"), 403

@app.errorhandler(404)
def not_found(e):
    return page("<div class='card'><h1>404 · Not found</h1><p>The requested resource was not found.</p><a class='btn' href='/dashboard'>Back to dashboard</a></div>"), 404

@app.errorhandler(413)
def too_large(e):
    return page("<div class='card'><h1>File too large</h1><p>Maximum upload size is 10 MB.</p><a class='btn' href='/dashboard'>Back</a></div>"), 413

init_db()
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
